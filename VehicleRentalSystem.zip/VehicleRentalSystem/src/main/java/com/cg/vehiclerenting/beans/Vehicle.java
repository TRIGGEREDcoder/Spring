package com.cg.vehiclerenting.beans;

public class Vehicle {
private String vehicleNo;
private String vehicleType;
private String vehicleName;
private String vehicleStatus;
private Customer customer;
private float vehicleRental;
private float usageRental;
}
