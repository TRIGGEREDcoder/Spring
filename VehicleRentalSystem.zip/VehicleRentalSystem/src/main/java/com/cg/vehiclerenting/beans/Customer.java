package com.cg.vehiclerenting.beans;

import java.util.Map;

public class Customer {

	private int customerID;
	private String firstName;
	private String lastName;
	private int mobileNo;
	private String aadharNo;
	private int days;
	private Vehicle vehicle;
}
