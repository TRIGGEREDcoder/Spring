package com.cg.vehiclerenting.beans;

public class Rental {
private int rentID;
private float totalAmount;
private float sgst;
private float cgst;
private float vehicleRentalAmount;
private float usageRentalAmount;

private Customer customer;
private Vehicle vehicle;
}
